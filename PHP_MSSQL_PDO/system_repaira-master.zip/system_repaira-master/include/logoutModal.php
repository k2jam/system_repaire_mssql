<div class="modal" id="logoutModal" role="dialog" tabindex="-1" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <i class="fas fa-sign-out-alt"></i> Are you sure you want to logout?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" onClick="document.location='apps/login/do_logout.php'">Yes</button>
      </div>
    </div>
  </div>
</div>
