<footer class="main-footer text-sm">
  <!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    v.0.1
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2019 <a href="https://www.facebook.com/CWCODING/">CWCODING</a>.</strong> All rights reserved.
</footer>
